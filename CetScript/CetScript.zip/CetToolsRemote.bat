@echo off

echo [ %DATE% %TIME% ]: The remote script is executed >> script.log

exit