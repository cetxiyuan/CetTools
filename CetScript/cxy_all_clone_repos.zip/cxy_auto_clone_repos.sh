#!/bin/bash
# 脚本信息
echo "##############################################################################"
echo "# 脚本名称: 工程仓库克隆工具(Linux)"
echo "# 版本: v1.0.0"
echo "# 作者: CetXiyuan"
echo "# 创建日期: 2025-12-04"
echo "# 最后修改: 2025-12-04"
echo "# 功能描述: 用于批量克隆指定Git仓库并切换到指定分支"
echo "#	    (不可分步指定仓库名和分支名)"
echo "# 典型用途: 项目工程初始化"
echo "# 依赖要求: "
echo "#   - Git 2.0+"
echo "#   - Bash 4.0+"
echo "# 使用示例: "
echo "#   ./git_auto_clone_repos.sh"
echo "# 注意事项:"
echo "#   1. 需要提前配置好SSH密钥"
echo "#   2. 需要有对应仓库的访问权限"
echo "# 版权声明: 本脚本仅供内部使用，未经许可不得外传"
echo "##############################################################################"

# 定义仓库列表
REPOS=("sdkenv" "appframe" "gpscode")
BASE_PATH="linux_code"  # 基础路径

# 读取用户输入
read -p "请输入Git服务器地址(默认:172.16.1.8): " SERVER
SERVER=${SERVER:-"172.16.1.8"}

# 读取项目导出路径
read -p "请输入项目导出路径(默认:当前目录): " EXPORT_PATH
EXPORT_PATH=${EXPORT_PATH:-$(pwd)}
# 创建导出目录（如果不存在）
mkdir -p "$EXPORT_PATH" || {
    echo -e "\033[31m创建导出目录失败!\033[0m"
    exit 1
}
# 进入导出目录
cd "$EXPORT_PATH" || {
    echo -e "\033[31m无法进入导出目录!\033[0m"
    exit 1
}
echo -e "\033[33m工程将导出到: $EXPORT_PATH\033[0m"

read -p "请输入分支全名(如 origin/temp/develop/c002d_JiangHuai_master_701): " BRANCH
if [ -z "$BRANCH" ]; then
    echo "错误：必须指定分支名称!"
    exit 1
fi

# 处理每个仓库
for repo in "${REPOS[@]}"; do
    # 设置仓库路径
    if [ "$repo" == "sdkenv" ]; then
        repo_path="envcode/$repo.git"
    else
        repo_path="appcode/$repo.git"
    fi
    
    full_repo="git@${SERVER}:${BASE_PATH}/${repo_path}"
    
    echo -e "\n\033[34m正在处理仓库: $repo\033[0m"
    echo -e "\033[36m完整地址: $full_repo\033[0m"
    echo -e "\033[36m目标分支: $BRANCH\033[0m"
    
    # 克隆仓库
    echo -e "\033[33m[执行] git clone '$full_repo' '$(pwd)/$repo'\033[0m"
    git clone "$full_repo" "$(pwd)/$repo" || {
        echo -e "\033[31m克隆仓库 $repo 失败!\033[0m"
        continue
    }
    
    cd "$repo" || continue
    
    # 切换分支
    local_branch=${BRANCH#origin/}
    echo -e "\033[33m[执行] git checkout -b '$local_branch' '$BRANCH'\033[0m"
    git checkout -b "$local_branch" "$BRANCH" || {
        echo -e "\033[31m切换分支失败! 可能分支不存在。\033[0m"
        if [ "$repo" != "sdkenv" ]; then
            cd ..
    	fi
        continue
    }
    
    echo -e "\033[33m[执行] git symbolic-ref --short HEAD\033[0m"
    echo -e "\033[32m当前分支: $(git symbolic-ref --short HEAD)\033[0m"
    if [ "$repo" != "sdkenv" ]; then
        cd ..
    fi

done

echo -e "\n\033[33m所有操作已完成! 工程已导出到: $EXPORT_PATH\033[0m"

