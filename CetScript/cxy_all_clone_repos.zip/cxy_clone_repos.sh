#!/bin/bash
# 脚本信息
echo "##############################################################################"
echo "# 脚本名称: 工程仓库克隆工具(Linux)"
echo "# 版本: v1.0.0"
echo "# 作者: CetXiyuan"
echo "# 创建日期: 2025-12-04"
echo "# 最后修改: 2025-12-04"
echo "# 功能描述: 用于批量克隆指定Git仓库并切换到指定分支"
echo "# 典型用途: 项目工程初始化"
echo "# 依赖要求: "
echo "#   - Git 2.0+"
echo "#   - Bash 4.0+"
echo "# 使用示例: "
echo "#   ./git_clone_repos.sh"
echo "# 注意事项:"
echo "#   1. 需要提前配置好SSH密钥"
echo "#   2. 需要有对应仓库的访问权限"
echo "# 版权声明: 本脚本仅供内部使用，未经许可不得外传"
echo "##############################################################################"

# 定义默认仓库配置（仓库名:默认仓库路径）
declare -A DEFAULT_REPO_PATHS=(
    ["sdkenv"]="linux_code/envcode/sdkenv.git"    # sdkenv 的默认仓库路径
    ["appframe"]="linux_code/appcode/appframe.git" # appframe 的默认仓库路径
    ["gpscode"]="linux_code/appcode/gpscode.git"  # gpscode 的默认仓库路径
)

# 读取用户输入
read -p "请输入Git服务器地址(默认:172.16.1.8): " SERVER
SERVER=${SERVER:-"172.16.1.8"}

# 读取项目导出路径
read -p "请输入项目导出路径(默认:当前目录): " EXPORT_PATH
EXPORT_PATH=${EXPORT_PATH:-$(pwd)}
# 创建导出目录（如果不存在）
mkdir -p "$EXPORT_PATH" || {
    echo -e "\033[31m创建导出目录失败!\033[0m"
    exit 1
}
# 进入导出目录
cd "$EXPORT_PATH" || {
    echo -e "\033[31m无法进入导出目录!\033[0m"
    exit 1
}
echo -e "\033[33m工程将导出到: $EXPORT_PATH\033[0m"

# 初始化分支记忆变量
pre_branch="origin/temp/develop/c002d_JiangHuai_master_701"

# 定义处理顺序（确保sdkenv第一个）
REPO_ORDER=("sdkenv" "appframe" "gpscode")

# 处理每个仓库
for repo in "${REPO_ORDER[@]}"; do
    # 读取该仓库的路径（如果未指定，则使用默认路径）
    default_repo_path="${DEFAULT_REPO_PATHS[$repo]}"
    read -p "请输入 $repo 的仓库路径(默认: $default_repo_path): " custom_repo_path
    repo_path="${custom_repo_path:-$default_repo_path}"

    # 读取该仓库的分支(必须指定)
    read -p "请输入 $repo 的分支名称(如 $pre_branch): " BRANCH
    BRANCH="${BRANCH:-$pre_branch}"
    if [ -z "$BRANCH" ]; then
        echo -e "\033[31m错误：必须指定 $repo 的分支名称!\033[0m"
        continue
    fi

    # 记忆当前分支
    pre_branch="${BRANCH}"

    full_repo="git@${SERVER}:${repo_path}"

    echo -e "\n\033[34m正在处理仓库: $repo\033[0m"
    echo -e "\033[36m完整地址: $full_repo\033[0m"
    echo -e "\033[36m目标分支: $BRANCH\033[0m"

    # 克隆仓库
    echo -e "\033[33m[执行] git clone '$full_repo' '$(pwd)/$repo'\033[0m"
    git clone "$full_repo" "$(pwd)/$repo" || {
        echo -e "\033[31m克隆仓库 $repo 失败!\033[0m"
        continue
    }

    cd "$repo" || continue

    # 切换分支（去掉 origin/ 前缀）
    local_branch="${BRANCH#origin/}"
    echo -e "\033[33m[执行] git checkout -b ’$local_branch‘ ’$BRANCH‘\033[0m"
    git checkout -b "$local_branch" "$BRANCH" || {
        echo -e "\033[31m切换分支失败! 可能分支不存在。\033[0m"
        if [ "$repo" != "sdkenv" ]; then
            cd ..
    	fi
        continue
    }

    echo -e "\033[33m[执行] git symbolic-ref --short HEAD\033[0m"
    echo -e "\033[32m当前分支: $(git symbolic-ref --short HEAD)\033[0m"

    if [ "$repo" != "sdkenv" ]; then
        cd ..
    fi
done

echo -e "\n\033[33m所有操作已完成! 工程已导出到: $EXPORT_PATH\033[0m"

